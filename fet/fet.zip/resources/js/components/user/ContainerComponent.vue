<template>
<div>
    <v-simple-table height="300px">
        <template v-slot:default>
            <thead>
                <tr>

                    <th class="text-left">options</th>
                    <th class="text-left">Name</th>
                    <th class="text-left">Email</th>
                    <th class="text-left">Created_at</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="item in listUsers" :key="item.id">
                    <td>
                        v-<button>
                            <v-icon color="orange">
                                mdi-pencil
                            </v-icon>
                        </button>
                        <v-icon color="orange">
                            mdi-pencil
                        </v-icon>

                    </td>
                    <td>{{ item.name }}</td>
                    <td>{{ item.email }}</td>
                    <td>{{ item.created_at }}</td>
                </tr>
            </tbody>
        </template>
    </v-simple-table>
</div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    computed: {
        ...mapState('user', ['listUsers']),

    },
    mounted() {
        this.$store.dispatch('user/getList');
    }
}
</script>
