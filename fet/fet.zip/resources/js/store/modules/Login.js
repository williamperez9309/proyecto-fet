import axios from 'axios';  

const state = {
    message: ''
}
const actions = {
    login({commit}, user){
        axios.post('http://localhost/fet/public/api/user/login', {
            email:user.email,
            password:user.password
        }).then (response => {
            if(response.data.access_token){
                localStorage.setItem("blog_token", response.data.access_token)
                window.location.replace('home')
            }
            if(response.data.message){
                commit('SetMessage', response.data.message)

            }
        })
    }
}
const mutations = {
    SetMessage(state, data){
        state.message = data 
    }
}


export default {
    namespaced: true,
    state, 
    actions,
    mutations
}