import axios from  "axios"

const state = {
    listUsers: [],
    currentUser: {}
}
const actions = {
    getList({commit}){
        axios.get('http://localhost/fet/public/api/user/users')
        .then(response => {
            console.log(response)
            commit('SetUsers', response.data.users)
        })
    },

    getCurrent({commit}){
        axios.get('http://localhost/fet/public/api/user/current')
        .then(response => {
            commit('SetCurrentUser', response.data)
        })
    }
}
const mutations = {
    SetUsers(state, data ){
        state.listUsers = data 
    },

    SetCurrentUser(state, data){
        state.currentUser = data

    }
}

export default {
    namespaced: true,
    state,
    actions,
    mutations
}