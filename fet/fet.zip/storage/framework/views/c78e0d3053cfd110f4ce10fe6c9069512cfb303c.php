<?php $__env->startSection('content'); ?>
    <login-component></login-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fet\resources\views/auth/login.blade.php ENDPATH**/ ?>